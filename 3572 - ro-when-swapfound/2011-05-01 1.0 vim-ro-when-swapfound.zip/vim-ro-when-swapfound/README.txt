vim-ro-when-swapfound
Open Vim in read-only mode when swapfile is found.

* mail@nanasi.jp
* http://nanasi.jp/
* https://github.com/taku-o/vim-ro-when-swapfound

see also
* Open same file read-only in second Vim
* http://vim.wikia.com/wiki/Open_same_file_read-only_in_second_Vim

