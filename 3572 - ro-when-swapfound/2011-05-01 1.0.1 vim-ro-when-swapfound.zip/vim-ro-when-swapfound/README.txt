vim-ro-when-swapfound
Open Vim in read-only mode when swapfile is found.

If swapfile is found, prevent to display attention dialog, and open Vim in read-only mode.
See also
* Open same file read-only in second Vim
* http://vim.wikia.com/wiki/Open_same_file_read-only_in_second_Vim

* mail@nanasi.jp
* http://nanasi.jp/
* https://github.com/taku-o/vim-ro-when-swapfound

