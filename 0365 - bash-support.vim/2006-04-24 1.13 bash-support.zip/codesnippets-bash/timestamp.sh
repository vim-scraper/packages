
timestamp=$(date +"%Y%m%d-%H%M%S")          # generate timestamp : YYYYMMDD-mmss

