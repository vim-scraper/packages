
fpdf.vim is a port of FPDF.

About FPDF:
  FPDF is a PHP class which allows to generate PDF files with pure PHP.
  See http://www.fpdf.org/


Requirement:
  :set encoding=utf-8 and iconv() feature for non-ascii text.
  xxd for image/font embedding.


Usage:
  :set runtimepath+=/path/to/fpdf-vim
  :so tutorial/tuto1.vim


Reference:
  See FPDF site.


Note that not all feature is tested and implemented yet.
