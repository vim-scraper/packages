What is this?
==================================
textmanip.vim is minimal utility for

  * duplicate text easily
  * move visually selected text easily

See [ScreenCast](http://www.youtube.com/watch?v=rXeendPlUBA)

How to Use
==================================
Please see [help](https://github.com/t9md/vim-textmanip/blob/master/doc/textmanip.txt).
