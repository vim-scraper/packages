# EasyChair Review Form Syntax for VIM

Syntax definition for EasyChair review files. The definition is based on
markdown so markdown (and html) syntax is mentioned in all standard text
sections.

Repository:   https://github.com/seebi/easychair.vim
Screenshot:   https://github.com/seebi/easychair.vim/raw/master/Screenshot.png
vimscript id: ???

