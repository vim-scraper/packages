VimSpeak
                                     Yasuhiro Matsumoto <mattn@mail.goo.ne.jp>

* What is this
  This is a dll which can speak text for GVim.

* Install
  copy vimspeak.dll to same directory with gvim.exe
  copy vimspeak.vim to your $VIMRUNTIME/plugin

* Usage
  [range]VimSpeak

  Have Fun!

