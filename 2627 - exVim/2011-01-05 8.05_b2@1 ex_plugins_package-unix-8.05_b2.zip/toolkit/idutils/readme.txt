copy id-lang.map to the %id-utils_path%/share
