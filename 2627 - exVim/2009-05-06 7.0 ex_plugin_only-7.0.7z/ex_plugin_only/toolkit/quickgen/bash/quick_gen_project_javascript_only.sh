# ======================================================================================
# File         : quick_gen_project_javascript_only.sh
# Author       : Wu Jie 
# Last Change  : 04/03/2009 | 00:49:30 AM | Friday,April
# Description  : 
# ======================================================================================

# ------------------------------------------------------------------ 
# Desc: 
# ------------------------------------------------------------------ 

export EX_DEV="/usr/local/share"
bash ${EX_DEV}/vim/toolkit/quickgen/bash/quick_gen_project.sh js $1 $2

