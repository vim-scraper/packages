#!/bin/sh
cp -r doc $HOME/.vim
cp -r plugin $HOME/.vim

