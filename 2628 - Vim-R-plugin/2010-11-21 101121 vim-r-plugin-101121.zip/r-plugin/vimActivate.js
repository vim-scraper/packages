var arg = WScript.Arguments.Item(0);
var WshShell = WScript.CreateObject("WScript.Shell");
WshShell.AppActivate(arg);

