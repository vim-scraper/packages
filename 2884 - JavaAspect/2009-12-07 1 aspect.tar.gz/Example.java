/*
 * File Name  : Example.java
 * Authors    : yiuwing
 * Created    : 2009-12-06 16:47:58
 */

/*
	Aspect Template 
	{
		#1 temp = delegate.#2(@@);
		return temp;
	}
 */
public class Example
{
	public void hello();

	public int doSomething(int i, int j);

	public String getString();
}
