What is this?
==================================

*tryit.vim* is minimal utility for

  * open scratch(=sandbox) file to try idea in that file.
  * paste visually selected text to that scrach buffer.

Thats' all!

I need workspace to try some idea when programming.

When I am considering "where to save", "what name should I name this file",
for this type of file used merly as workspace , I consume limited brain
resources for that.

I usually use this plugin with combination of thinca's |quickrun|.

quickrun:~
  http://www.vim.org/scripts/script.php?script_id=3146

while I read some source code, and have question for code fragment.

1. select that code fragment.
2. then `T`( my favorite keymap for <Plug>(tryit-this) )
3. then |:Quickrun|.

How to use
==================================
See [help](https://github.com/t9md/vim-tryit/blob/master/doc/tryit.txt)
