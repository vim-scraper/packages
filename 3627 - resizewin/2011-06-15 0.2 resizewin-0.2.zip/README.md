What is this?
==================================
resizewin.vim is minimal utility for resize win

  * horizontally
  * vertically
  * full(both horizontally and vertically)

KeyMap Example
================================
set following keymap in your .vimrc.
then split, vsplit several time.
then try `_`, `|`(bar), `F`

		vmap _ <Plug>(ResizeH)
		vmap <bar> <Plug>(ResizeV)
		vmap F <Plug>(ResizeHV)
		nmap _ <Plug>(ResizeH)
		nmap <bar> <Plug>(ResizeV)
		nmap F <Plug>(ResizeHV)

Command
===================================================
#### ResizeH
resize horizontally

#### ResizeV
resize vertically

#### ResizeHV
resize horizontally and vertically
