// cca: start="<{" : end="}>" :
#include <iostream>
using namespace std;

int main(void)
{
    <{}>
    return 0;
}
