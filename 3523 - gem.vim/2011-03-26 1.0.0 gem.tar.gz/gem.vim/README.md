gem.vim a project helper for ruby gem/libraray development
===========================================================

Overview
--------

easy navigation in gem directory. have :R :Rl :Rs command, and :A alternative for quich switch between lib and spec file. It works with rag(see resources). for more information please see doc/gem.txt

Install
-------

	vimana install gem.vim # see resources to get vimana

Resources
---------

* [Rag](https://github.com/GutenLinux/tag): a project helper
* [Rails.vim](https://github.com/tpope/vim-rails): a powerful tool for Ruby on Rails development
* [NERD](https://github.com/scrooloose/nerdtree): a tree explorer in vim
* [Vimana](https://github.com/c9s/Vimana): vim's package manager
