# Miscellaneous auto-load Vim scripts

The git repository at <http://github.com/xolox/vim-misc> contains Vim scripts
that are used by most of the [Vim plug-ins I've written] [plugins] yet don't
really belong with any single one. I'm hoping to include this repository as a
git submodule in my other repositories so that I only have to maintain these
files in one place.

For lack of a better place: I hereby release these scripts under the MIT
license, in other words feel free to do with them as you please but don't
misrepresent this work as your own.

[plugins]: http://peterodding.com/code/vim/
