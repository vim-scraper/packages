/******************************************************************************
 * file:        $RCSfile$ $Revision$
 * module:      @LASTDIR@
 * authors:     YOURNAME
 * last mod:    $Author$ at $Date$
 *
 * created:     @DATE@
 *
 * copyright:   (c) @YEAR@ YOURNAME
 *
 * notes:
 *
 *****************************************************************************/

