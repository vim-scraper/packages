/******************************************************************************
 * file:        $RCSfile$ $Revision$
 * module:      @LASTDIR@
 * authors:     YOURNAME
 * last mod:    $Author$ at $Date$
 *
 * created:     @DATE@
 *
 * copyright:   (c) @YEAR@ YOURNAME
 *
 * notes:
 *
 *****************************************************************************/
#ifndef @INCLUDE_GAURD@
#	define @INCLUDE_GAURD@

#endif /* @INCLUDE_GAURD@ */
