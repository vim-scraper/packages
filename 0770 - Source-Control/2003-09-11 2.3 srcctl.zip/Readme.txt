SrcCtl:  Version 2.3

Michael Geddes

Generic Source Control

Supported repositories
    - Visual Source Safe
    - Star Team (Starbase/Borland)

To install, unzip with directories into your .vim/ vimfiles/ directory.

Install new compatible source-control modules into the srcctl/ directory.

NOTE:

This script is used at your own risk.

Please feel free to use and modify all or part of this script.
I would appreciate being acknowledged in any derived scripts, and would 
appreciate any updates/modifications.

