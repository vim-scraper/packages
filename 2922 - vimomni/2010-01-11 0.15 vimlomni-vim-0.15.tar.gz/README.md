
Vim Omni Completion
===================
although vim has its own completion (C-x C-v), but it''s leak of something

vim omni supports:

    * builtin command completion.
    * builtin function completion.
    * runtime command completion.
    * runtime function name completion.
    * g:,s:.. scope completion.
    * context completion.
    * option name completion.

INSTALL
=======

copy `ftplugin/vim/omni.vim` to your `~/.vim/ftplugin/vim/omni.vim`


SCREENSHOT
==========

![](http://cloud.github.com/downloads/c9s/vimomni.vim/Screen_shot_2010-01-10_at_10.44.58_AM.png)
![](http://cloud.github.com/downloads/c9s/vimomni.vim/Screen_shot_2010-01-10_at_10.44.45_AM.png)
![](http://cloud.github.com/downloads/c9s/vimomni.vim/Screen_shot_2010-01-10_at_10.44.30_AM.png)
