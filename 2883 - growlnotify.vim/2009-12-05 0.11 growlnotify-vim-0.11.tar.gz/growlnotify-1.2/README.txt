growlnotify is a command-line tool to post Growl notifications. You can control all aspects of the notification (within any boundaries set up in the Growl pane of System Preferences). It can be very useful in shell scripts.

Information on usage is in the manpage. Just type 'man 1 growlnotify' after installing.
