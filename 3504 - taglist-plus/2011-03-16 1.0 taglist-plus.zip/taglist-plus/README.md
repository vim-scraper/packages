taglist-plus.vim
================

This is a fork of the popular taglist.vim plugin.

Taglist-plus supports jsctags for excellent Javascript tagging. See [here][1]
for examples.

[1]:http://discontinuously.com/2011/03/vim-support-javascript-taglist-plus/
