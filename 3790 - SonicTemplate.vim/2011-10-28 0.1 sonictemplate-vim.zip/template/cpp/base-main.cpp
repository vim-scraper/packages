#include <iostream>
#include <string>

int
main(int argc, char* argv[]) {
	{{_cursor_}}
	return 0;
}
