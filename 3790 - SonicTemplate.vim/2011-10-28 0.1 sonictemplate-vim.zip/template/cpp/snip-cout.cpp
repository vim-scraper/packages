std::cout << {{_input_:string}} << std::endl;
