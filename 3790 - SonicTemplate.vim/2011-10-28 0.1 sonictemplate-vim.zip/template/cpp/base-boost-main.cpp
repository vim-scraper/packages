#include <iostream>
#include <string>
#include <boost/foreach.hpp>

int
main(int argc, char* argv[]) {
	{{_cursor_}}
	return 0;
}
