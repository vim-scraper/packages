#include <stdio.h>

int
main(int argc, char* argv[]) {
	{{_cursor_}}
	return 0;
}
