for (int n = 0; n < {{_input_:count}}; n++) {
	{{_cursor_}}
}
