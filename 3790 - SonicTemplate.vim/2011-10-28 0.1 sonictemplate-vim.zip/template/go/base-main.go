package main

func main() {
	{{_cursor_}}
}
