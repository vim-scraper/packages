go func() {
	{{_cursor_}}
}()
