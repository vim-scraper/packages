(function() {
	{{_cursor_}}
})();
