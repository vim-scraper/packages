$.each({{_input_:variable}}, function() {
	{{_cursor_}}
});
