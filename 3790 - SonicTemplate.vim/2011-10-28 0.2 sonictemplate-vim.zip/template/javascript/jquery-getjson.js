$.getJSON("{{_input_:URL}}", function(data) {
	{{_cursor_}}
});
