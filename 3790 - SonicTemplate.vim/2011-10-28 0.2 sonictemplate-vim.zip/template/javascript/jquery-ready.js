$(function() {
	{{_cursor_}}
});
