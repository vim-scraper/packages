(function() {
	{{_cursor_}}
})
