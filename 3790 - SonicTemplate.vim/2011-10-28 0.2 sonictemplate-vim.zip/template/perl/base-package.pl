package {{_expr_:substitute(substitute(substitute(expand('%'), '.*lib[\\/]', '', 'g'), '[\\/]', '::', 'g'), '\.pm$', '', 'g')}};

use strict;
use warnings;
use utf8;

{{_cursor_}}

1
