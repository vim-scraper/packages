sub {{_input_:function name}} {
	my ($self{{_input_:arguments}}) = @_;
	{{_cursor_}}
}

