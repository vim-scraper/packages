# vim: fileencoding=utf-8

def main():
	{{_cursor_}}

if __name__ == '__main__':
	main()

