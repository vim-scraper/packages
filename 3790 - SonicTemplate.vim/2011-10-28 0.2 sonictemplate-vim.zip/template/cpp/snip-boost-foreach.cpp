BOOST_FOREACH(auto x, {{_input_:variable}}) {
	{{_cursor_}}
}
