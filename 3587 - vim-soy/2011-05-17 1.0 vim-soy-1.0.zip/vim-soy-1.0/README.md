# vim-soy

Syntax highlighting file for editing Google's Closure templating language.

To install, just copy the syntax/ and ftdetect/ directories to a directory in your runtimepath (~/.vim on Linux, $HOME/vimfiles in Windows)

Cold folding and auto-indenting would be nice to have, but are not currently on the to-do list. Help with these will be appreciated.
