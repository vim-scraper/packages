

use base qw(Jifty);

sub test1 { 
}


sub test2 {

}

sub current_user {

}


sub fail {
    my $self = shift;
    $self->
    $self->app_class
    Jifty->_
    LWP::UserAgent->
}
