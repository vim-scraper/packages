use base qw(Jifty);

use base qw(Jifty);

use base qw(
  Jifty
  Jifty::DBI
);

use base 'Test';
# \(^use base\_[\n ]\+qw[([{]\s*\)\@<=
