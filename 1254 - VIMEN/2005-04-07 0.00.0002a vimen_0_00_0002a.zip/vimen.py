if __name__ == '__main__':
  import core
  core.main()
