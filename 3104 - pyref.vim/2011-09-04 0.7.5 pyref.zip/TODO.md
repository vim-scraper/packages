# To-do list

 * Switch to `python-doc` package instead of `python2.6-doc`?
