
0.8.2 / 2011-09-01 
==================

  * updated function list
  * removed extra stylus from properties cluster
