0
def sqfjkm(qskjf):
  qsfdjm
  return qsjkfd


:
      
    

