
ColorScheme Selector Plugin
===========================
provide emacs-like colorscheme selector buffer.


Commands
========

      :SelectColorS  

      :EditCurrentColorS

BufferMapping
=============

`<C-q>`   quit window.

`e`       edit color scheme.
