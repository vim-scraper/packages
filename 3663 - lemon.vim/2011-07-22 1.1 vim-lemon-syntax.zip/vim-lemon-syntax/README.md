Crappy syntax highlighting in Vim for [Lemon Parser Generator](http://www.hwaci.com/sw/lemon/)
grammars.

Put syntax/lemon.vim in `~/.vim/syntax`, and ftdetect/lemon.vim in `~/.vim/ftdetect/`
optionally add `autocmd FileType lemon set nocindent noai indentkeys=` to ~/.vimrc to prevent autoindent.
