public class Java {
   public Java() {
      for(int i=0; i<10; i++)
         System.out.println(i);
   }
}
