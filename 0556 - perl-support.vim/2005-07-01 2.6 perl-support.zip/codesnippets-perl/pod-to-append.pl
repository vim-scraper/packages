
__END__

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#  Module Documentation
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

=head1 NAME

script name  -  short description

=head1 SYNOPSIS

How to use this script.

=head1 DESCRIPTION

Long description of his script.

=over 2

=item Input


=item Output


=back


=head1 EXAMPLES


=head1 BUGS

=head1 SEE ALSO

=head1 COPYRIGHT
    Copyright (c) YEAR   AUTHOR. All rights reserved.

    This library is free software; you can redistribute it and/or modify it
    under the same terms as Perl itself.

    This program is distributed in the hope that it will be useful, but
    without any warranty; without even the implied warranty of
    merchantability or fitness for a particular purpose.
    This library is free software; you can redistribute it and/or modify it
    under the same terms as Perl itself.

=head1 AUTHOR


=cut

