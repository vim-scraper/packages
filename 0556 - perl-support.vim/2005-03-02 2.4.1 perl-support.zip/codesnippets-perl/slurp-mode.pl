{
  my  $/  = undef;                              # input record separator undefined
  $data = <INFILE>;                             # store data in a scalar
}
