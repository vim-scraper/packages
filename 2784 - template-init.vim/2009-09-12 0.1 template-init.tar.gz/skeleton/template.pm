package {{!vim:PerlPackageName()}};
use warnings;
use strict;


{{!perl:print q|test|}}


1;
