
public main static void main(String[] ars) {
    System.exit(0);
}

