# Vim Rebar Plugin

A Vim plugin that makes it easy to use Rebar inside of Vim.

## Author(s)

* Susan Potter [@SusanPotter](http://twitter.com/SusanPotter)

## Copyright

Copyright (c) 2011 Susan Potter <me@susanpotter.net>.  All rights reserved.

## License

The source code is released as an open source project under the BSD license. 
Details of the license can be found in LICENSE of this source code 
distribution.
