#!/bin/sh

awk -f download.awk vplinst.conf
