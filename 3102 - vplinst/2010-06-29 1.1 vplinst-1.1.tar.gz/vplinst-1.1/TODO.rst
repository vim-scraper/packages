TODO
====

* Add support for curl when fetching files (in the download) function of the
  setup.sh script.
* Add support for git.
