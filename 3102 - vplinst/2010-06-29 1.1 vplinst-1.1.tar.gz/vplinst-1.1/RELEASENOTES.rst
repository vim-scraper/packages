Changes from vplinst-1.0 to vplinst-1.1
---------------------------------------

    * Fixed bug: tar was not being executed for .tgz files.
    * New TODO.rst file in the source distribution
    * Added support for ftp - now supporting ftp and wget.
    * Added the RELEASENOTES.rst file, with releasing information.
