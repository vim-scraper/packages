Send (MAPI) mail via vim.

To use, see the comments in vimmailr.vim.

To build the dll (vimmailr.dll), load up the dsw project
file in msdev and build.

My contact info is in vimmailr.vim if you have any comments.

Enjoy!
Ward

