import sys


def error(m):
    sys.stderr.write(str(m) + '\n')
