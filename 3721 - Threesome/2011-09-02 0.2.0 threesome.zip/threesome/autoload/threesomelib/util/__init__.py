# This is kind of a dirty hack.  Feels bad, man.
from bufferlib import buffers
