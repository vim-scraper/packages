/* file name  : <FILENAME>.cpp
 * author     : Your Name Here
 * created    : <TIMESTAMP>
 * copyright  : <YEAR> Your Name Here
 * version    : $Revision$
 */

#include "<HEADER>.h"

<CONSTRUCTORS>

<METHODS>

/*
 * change log
 *
 * $Log$
 */

