Place these files in your Vim runtime directory.

To see your runtime directory type in the command:
:set runtimepath

On Unix machines this defaults to ~/.vim/

In Windows you can place this in your vimfiles directory where VIM was installed.
e.g. C:\Program Files\Vim\vimfiles

To be perfectly certain check the path for your own operating system.

- Eric
