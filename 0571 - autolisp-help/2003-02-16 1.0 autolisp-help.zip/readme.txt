This is a Vim style help file of Auto/Visual Lisp functions. 
Place it in vimfiles/doc/ and use :helptags {dir} to generate
a new tags file. I also have this mapping in my vimrc file.
map <leader>hh :he <C-R><C-W><CR>
Place your cursor on a function and type '\hh' or what ever you
have 'leader' set to. Or can simply type :he <AutoLISP function>
to open the help file to a function.

See Vim help
 :he helptags
 :he leader

mark.thomas@bigswamp.org
