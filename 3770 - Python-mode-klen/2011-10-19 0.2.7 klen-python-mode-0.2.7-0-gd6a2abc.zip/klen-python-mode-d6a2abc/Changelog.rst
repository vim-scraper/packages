Changelog
=========

## 2011-10-19 0.2.7
-------------------
* Minor fix (virtualenv loading)

## 2011-10-18 0.2.6
-------------------
* Add <C-space> shortcut for macvim users.
* Add VIRTUALENV support

## 2011-10-17 0.2.4
-------------------
* Add current work path to sys.path
* Add 'g:pymode' option (disable/enable pylint and rope)
* Fix pylint copyright
* Hotfix rope autocomplete

## 2011-10-15 0.2.1
-------------------
* Change rope variables (ropevim_<name> -> pymode_rope_<name>)
* Add "pymode_rope_auto_project" option (default: 1)
* Update and fix docs
* 'pymode_rope_extended_complete' set by default
* Auto generate rope project and cache
* "<C-c>r a" for RopeAutoImport

## 2011-10-12 0.1.4
-------------------
* Add default pylint configuration

## 2011-10-12 0.1.3
-------------------
* Fix pylint and update docs

## 2011-10-11 0.1.2
-------------------
* First public release
