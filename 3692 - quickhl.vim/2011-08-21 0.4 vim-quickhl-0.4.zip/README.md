       .oooooo.                o8o          oooo       oooo       oooo  
      d8P'  `Y8b               `"'          `888       `888       `888  
     888      888  oooo  oooo oooo  .ooooo.  888  oooo  888 .oo.   888  
     888      888  `888  `888 `888 d88' `"Y8 888 .8P'   888P"Y88b  888
     888      888   888   888  888 888       888888.    888   888  888  
     `88b    d88b   888   888  888 888   .o8 888 `88b.  888   888  888  
      `Y8bood8P'Ybd'`V88V"V8P'o888o`Y8bod8P'o888o o888oo888o o888oo888o

quickhl.vim is minimal utility for

* quickly highlight `<cword>`
* quickly highlight visually selected text.

### [ScreenCast](http://www.youtube.com/watch?v=W_XJlTbuoyI)
### [help](https://github.com/t9md/vim-quickhl/blob/master/doc/quickhl.txt)

![quickhl.png](https://github.com/t9md/t9md/raw/master/img/quickhl.png)

