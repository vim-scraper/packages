
apt-complete.vim
============
provide deb package name completion.


commands:
=========

    :AptCompleteOn   # turn deb package completion on
    :AptCompleteOff  # turn deb package completion off (set `completefunc` back)
