#!/bin/bash

vim -c 'MPC'
