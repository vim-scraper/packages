/*
 * @FILE@
 * author: @AUTHOR@
 * date: @DATE@
 * @CVS_REVISION@
 * description:
 */

#include <stdio.h>

int main(int argc, char **argv) /* {{{ */
{
    return 0;
} /* }}} */
