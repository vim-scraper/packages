"""
FILENAME: @FILENAME@
AUTHOR:   @AUTHOR@
DATE:     @DATE@
@CVS_REVISION@
DESCRIPTION:
"""
import sys,os

def main():
    pass

if __name__=="__main__":main()
