#!/bin/bash
# FILENAME: @FILE@
# AUTHOR:   @AUTHOR@
# DATE:     @DATE@
# DESCRIPTION:
# @CVS_REVISION@
