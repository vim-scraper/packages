/*
 * FILENAME: @FILE@
 * AUTHOR:   @AUTHOR@
 * DATE:     @DATE@
 * @CVS_REVISION@
 * DESCRIPTION:
 */
#include <iostream>
using namespace std;

int main(int argc, char **argv) /* {{{ */
{
    cout << "hello" << endl;
    return 0;
} /* }}} */
