/*
 * @FILE@
 * author: @AUTHOR@
 * date: @DATE@
 * @CVS_REVISION@
 * description:
 */

#ifndef @INCLUDE_GUARD@
#define @INCLUDE_GUARD@


#endif /* ifndef @INCLUDE_GUARD@ */
