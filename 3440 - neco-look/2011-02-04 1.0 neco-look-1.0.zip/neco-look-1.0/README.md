# neocomplcache-look (neco-look)

A neocomplcache plugin for `/usr/bin/look` for completing English.

## install

* install the latest neocomplcache.vim
* make sure if you already have `look` command
* Unarchive neco-look and put it into a dir of your &rtp.

## Author

Tatsuhiro Ujihisa
