HiVim; The GVim color scheme creator.
HiVim will create the color scheme of your selection...
 
If you need more/different aspect values (Comment, LineNr, etc) 
you can type those (case sensitive) directly into the top menu.
Or you can edit the source code and add those to the menu yourself.

If you want to make a picture for the aspect (Many are missing because
I don't know what they are), you can add a 130x92 *.ppm image of the
same name to HiVim/Images (Vsplit.ppm for Vsplit).

You need Tcl/Bwidget/Tix libraries to run this.

Write me at saftousmis@gmail.com if you have any questions.

Stratis Aftousmis
