print ( =~s/\./\./)
