<?php
    /*
    @{FILE NAME}@{NOTE}
    @Author:      @{AUTHOR} (@{EMAIL})
    @License:     @{LICENSE}
    @Created:     @{DATE}.
    Description:
    Usage:
    TODO:
    CHANGES:
    */

    @@
?>

