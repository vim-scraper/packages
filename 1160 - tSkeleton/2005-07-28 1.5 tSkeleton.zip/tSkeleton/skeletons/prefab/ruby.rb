#!/usr/bin/env ruby
# <+FILE NAME+><+NOTE+>
# @Author:      <+AUTHOR+> (<+EMAIL+>)
# @Website:     <+WEBSITE+>
# @License:     <+LICENSE+>
# @Created:     <+DATE+>.
# @Last Change: 02-M�r-2005.
# @Revision:    0.0
#
# = Description
# = Usage
# = TODO
# = CHANGES

# require ''

# <+FILE NAME ROOT:cs*\W*_*+>: <+CURSOR+>
class <+FILE NAME ROOT:cs*\W*_*+>
    <+BODY+>
end


if __FILE__ == $0
end

