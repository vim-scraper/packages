#!/bin/bash
# <+FILE NAME+> -- created <+DATE+>, <+AUTHOR+>
# @Last Change: 24-Dez-2004.
# @Revision:    0.0

<+CURSOR+>

# vi: 
