<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
       "http://www.w3.org/TR/html4/transitional.dtd">
<html>
<head>
    <title><+TITLE+></title>
    <link rel="stylesheet" type="text/css" href="<+CSS+>.css">
</head>
<body>

<?php
/*      
@{FILE NAME}@{NOTE}
@Author:      @{AUTHOR} (@{EMAIL})
@License:     @{LICENSE}
@Created:     @{DATE}.
Description:
Usage:
TODO:
CHANGES:
*/

   @@

?>

</body>
</html>

