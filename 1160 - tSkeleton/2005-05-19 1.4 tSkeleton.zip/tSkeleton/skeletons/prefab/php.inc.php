<?php
/*
<+FILE NAME+><+NOTE+>
@Author:      <+AUTHOR+> (<+EMAIL+>)
@License:     <+LICENSE+>
@Created:     <+DATE+>.
@Last Change: 15-Mai-2005.
@Version:     0.0
Description:
Usage:
TODO:
CHANGES:
*/

<+CURSOR+>

?>
