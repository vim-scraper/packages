 rest markup mode test file, no gotchas
 converted from test_outline.txt

findme findme2

=
1    
=
   1 body

---
1.1    
---
   1.1 body

---
1.2    
---
   1.2 body

=
2    
=
   2 body

=
3    
=
   3 body

---
3.1    
---
   3.1 body

---
3.2    
---
   3.2 body


3.2.1  
=====
   3.2.1 body


3.2.1.1  
-------
   3.2.1.1 body
  xxxx findme findme


3.2.2  
=====
   3.2.2 body


3.2.2.1  
-------
   3.2.2.1 body


3.2.2.1.1  
*********
   3.2.2.1.1 body


3.2.2.1.2  
*********
   3.2.2.1.2 body

---
3.3    
---
   3.3 body

=
4    
=
   4 body

---
4.1    
---
   4.1 body findme

=
5    
=
   5 body

---
5.1    
---
   5.1 body

---
5.2    
---
   5.2 body


5.2.1  
=====
   5.2.1 body


5.2.2  
=====
   5.2.2 body


5.2.2.1  
-------
   5.2.2.1 body


5.2.2.1.1  
*********
   5.2.2.1.1 body


5.2.2.1.2  
*********
   5.2.2.1.2 body



5.2.3  
=====
   5.2.3 body

--
AA    
--
a a a a


AA.1  
====
a1 a1 a1 a1

--
BB    
--
b b b b


BB.1  
====
b1 b1 b1 b1 b1

---
5.3    
---
   5.3 body
findme

=====
tests    
=====

------------
syntax tests    
------------
Since v2.1 comment chars before foldmarker are stripped according to filetype.


//---TODO comment--- //  
=======================


"---comment--- "  
================
echo 'vim ok'


#---comment--- #  
================
print 'py ok'


%---comment--- %  
================


/*---comment--- /*  
==================


*/---not comment--- /*  
======================


<!-- Comment  
============


html head <!  
============

--------------
Voomgrep tests    
--------------
:Voomg Spam and ham not bacon
:Voomg Spam and\ ham not\ bacon
:Voomg Spam and\\ ham not\\ bacon
\Spam// ' "


n42 breakfast  
=============
eggs
bacon


n43 lunch  
=========
Spam Spam Spam Spam Spam Spam Spam Spam Spam 
Spam Spam Spam Spam Spam Spam Spam Spam Spam 
Spam Spam Spam Spam Spam Spam Spam Spam Spam 
ham


n44 dinner  
==========
eggs
Spam
ham


n45 snack  
=========
bacon
spam
HAM
beef

----------
sort tests    
----------


node 2  
======


dddd  
----
d1


eeee  
----


dddd  
----
d2



bbbb  
----
b


b_yyy  
*****


b_xxx  
*****


cccc  
----
c


aaaa  
----
a

a_nnn  
*****


a_mmm  
*****


node 22  
=======



ñ  
=


Ñ  
=
unicode tests


э  
-
1

Я  
-
2

ю  
-
3

Э  
-
4

я  
-
5

Ю  
-
6


node 1  
======


bbbb  
----
b


dddd  
----
d1


DDDD  
----
ingorecase test


aaaa  
----
a

dddd  
----
d2



cccc  
----
c


z  
=

-------------------
special chars tests    
-------------------


'" /\\/  
=======
" "" """
' '' """
\ \\ \\\
/ // ///
\//\


Брожу ли я  
==========
    Брожу. Чего ж не побродить.

Чебурашка CHeburashka
u'\u0427\u0435\u0431\u0443\u0440\u0430\u0448\u043a\u0430'
utf-8
'\xd0\xa7\xd0\xb5\xd0\xb1\xd1\x83\xd1\x80\xd0\xb0\xd1\x88\xd0\xba\xd0\xb0'


